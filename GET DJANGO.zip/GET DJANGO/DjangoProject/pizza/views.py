from django.shortcuts import render
from .models import pizzaVarity

# Create your views here.
def all_pizza(request):
    pizzas = pizzaVarity.object.all()
    return render (request, 'pizza/all_pizza.html')
