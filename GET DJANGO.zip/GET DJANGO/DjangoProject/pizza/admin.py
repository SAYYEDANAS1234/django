from django.contrib import admin
from .models import pizzaVarity



# Register your models here.
admin.site.register(pizzaVarity)

def _str_(self):
   return self.name    