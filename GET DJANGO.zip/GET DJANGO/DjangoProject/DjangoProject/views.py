from django.http import HttpResponse
from django.shortcuts import render 

def home(request):
    #return HttpResponse("HELLO,This is our Frist Django Website")
    return render (request,'index.html');

def about(request):
    return HttpResponse("HELLO, This is our About Page");

def contact(request):
    return HttpResponse("HELLO,This is our Contact Page");